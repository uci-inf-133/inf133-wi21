import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { TodoService } from '../services/todo.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
})
export class ListPage implements OnInit {
  tasks:String[]
  constructor(private service: TodoService, private navCtrl: NavController) { }

  ngOnInit() {
    this.tasks = this.service.getTasks();
  }

  delete(task){
    this.service.delete(task);
    this.tasks = this.service.getTasks();
  }

  goBack() {
    this.navCtrl.back();
  }

}
