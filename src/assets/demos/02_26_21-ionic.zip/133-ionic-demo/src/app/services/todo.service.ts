import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
  private tasks: String[] = ["Finish grading A3"]
  constructor() { }

  addTasks(task){
    this.tasks.push(task);
  }

  getTasks(){
    return this.tasks.slice();
  }

  delete(task){
    this.tasks = this.tasks.filter((item) => item !== task)
  }
}
