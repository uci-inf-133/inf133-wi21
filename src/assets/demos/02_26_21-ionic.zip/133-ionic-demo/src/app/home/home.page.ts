import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TodoService } from '../services/todo.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  task:String = ''
  constructor(private service: TodoService, private router: Router) {}

  addTask() {
    console.log(this.task)
    this.service.addTasks(this.task);
  }

  toList() {
    this.router.navigate(['/list']);
  }

}
