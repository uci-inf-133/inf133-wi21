import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  loggedIn:boolean = false;
  username:string = undefined;

  constructor() {
  	//TODO: try to get the username from Firebase.
    //If a value is returned, update the username field and set loggedIn to true.
  }

  logIn() {
  	//TODO: set the username in Firebase and set loggedIn to true.
  }

}
