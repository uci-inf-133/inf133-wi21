import { Injectable } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Injectable()
export class GroceriesService {
  //If there is time, teach about event emitter with the demo part2 project
  //this emitter is an observable, and will shoot a change to anyone who subscribes to it (that is why it is not a private property)
  groceryChanged = new EventEmitter<String[]>();

  //private because we want this service to be a "source of truth" about the list, only it can change the list, based on actions called to it
  private grocerylist:String[] = [
    'potato',
    'melon'
  ];

  constructor() { }

  //slice because it is a copy, we don't want to hand out a real reference to the grocerielist
  public getGrocerieList():String[]{
    return this.grocerylist.slice();
  }

  public addItem(item: String){
    this.grocerylist.push(item);
    //shoot the emition of a new list, since it was changed
    this.groceryChanged.emit(this.grocerylist.slice());
  }

}
