import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TwitterService {

  constructor() { }

  getTweets():Promise<any> {
  	return Promise.resolve();
  }
}
