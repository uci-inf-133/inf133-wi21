import { Component } from '@angular/core';
import { Plugins, CameraResultType, CameraPhoto, CameraSource } from '@capacitor/core';

const { LocalNotifications, Camera, Share } = Plugins;

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	readyForSelfie:boolean = false;
	selfieTaken:boolean = false;
	photo:CameraPhoto = null;

  constructor() {}

  async scheduleSelfie() {
   	await LocalNotifications.requestPermission();
    var notification = await LocalNotifications.schedule({
      notifications: [
        {
          title: 'Daily Selfie Reminder',
          body: 'Time to take a selfie!',
          id: 1,
          schedule: { at: new Date(Date.now()) },
        },
      ],
    });
    //You'd ideally want to listen for the notification to be received, but this does not appear to be enabled for web
    this.readyForSelfie = true;
  }

  async takeSelfie() {
  	this.photo = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 100,
    });
    this.selfieTaken = true;
  }

  async shareSelfie() {
  	//Can't actually share the file because web support currently doesn't enable it :-(
  	Share.share({
      text: 'Hello from IN4MATX 133 lecture!',
      dialogTitle: 'Share with TAs'
    });
  }
}
