import { Component } from '@angular/core';
import { Plugins, CameraResultType, CameraPhoto, CameraSource } from '@capacitor/core';

//TODO: Load plugins from capacitor's plugins

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
	readyForSelfie:boolean = false;
	selfieTaken:boolean = false;
	photo:CameraPhoto = null;

  constructor() {}

  async scheduleSelfie() {
  	//TODO: Use LocalNotifications to request permission to send notifications
  	//and schedule a reminder to take a selfie in ~3 seconds
    //You'd ideally want to listen for the notification to be received,
    //but this does not appear to be enabled for web
    this.readyForSelfie = true;
  }

  async takeSelfie() {
  	//TODO: Use Camera to take a photo and store it in the photo variable
    this.selfieTaken = true;
  }

  async shareSelfie() {
  	//TODO: Use Share to share the photo
  	//Unfortunately, we can't share the file because the web plugin is limited :-(
  	//but we can send the TAs a text instead :-)
    //informatics-133-staff@uci.edu
  }
}
