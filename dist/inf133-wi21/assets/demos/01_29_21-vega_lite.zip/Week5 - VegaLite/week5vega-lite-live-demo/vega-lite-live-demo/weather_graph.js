//window.onload = ()=> {
$(document).ready(() => {

	var schema = {
		"$schema": "https://vega.github.io/schema/vega-lite/v4.0.0-beta.8.json",
		"data": { "url": "https://vega.github.io/editor/data/seattle-weather.csv" },
		"mark": "bar",
		//	Demonstrate transform using filter to filter data
		
		"transform": [
			//{ "filter": { "timeUnit": "year", "field": "date", "equal": "2015" } },
			{ "filter": { "timeUnit": "month", "field": "date", "equal": "Jan" } }
		],
		
		"encoding": {
			"x": {
				//"timeUnit": "month",		// Used to discretize times in vega-lite (bin a date string as a month)
				"timeUnit": "year",		// Change to display year
				"field": "date",
				"type": "ordinal"
			},
			"y": {
				"aggregate": "count",		// count operates directly on the input objects
				"field": "*",				// All records
				"type": "quantitative"
			},
			"color": {			// Color of the marks, based on the data field
				"field": "weather",
				"type": "nominal"
			},

			"tooltip": {
				"field": "weather",
				"type": "nominal"
			}
			
		}
	}
	vegaEmbed('#plot', schema, { actions: false });
});