$(document).ready(() => {

    var schema = {
        "data": { "url": "https://vega.github.io/editor/data/cars.json" },
        "mark": "bar",
        // "transform": [
        //     {"filter": {"field": "Origin", "equal": "USA"}}
        //     {"filter": {"timeUnit": "year", "field": "Year", "gte": "1979"}}
        // ],
        "encoding": {
            "x": { "field": "Cylinders", "type": "ordinal" },
            "y": { "aggregate": "mean", "field": "Acceleration", "type": "quantitative" }
        }
    }

    vegaEmbed('#plot', schema, { actions: false });
});